<?php
/*
Plugin Name:  Dynamic text area
Plugin URI:   http://www.waydesign.nl/dynamictextarea
Description:  Retrieves file with same page slug as the url, gets the content from within a .docx file
Version:      0.1
Author:       http://www.waydesign.nl
Author URI:   http://www.waydesign.nl
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  wporg
Domain Path:  /languages
Shortcode Syntax: Default:[textload] || [textload type="textone"] || [textload type="texttwo"] || [textload type="textthree..."]
*/

// Plugin updater

require 'plugin-update-checker/plugin-update-checker.php';
$myUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://advandm297.297.axc.nl/dynamic-text-area.json',
	__FILE__,
	'dynamic_text_area_updater'
);

// Plugin registration
register_activation_hook( __FILE__, 'pluginprefix_function_to_run' );
register_deactivation_hook( __FILE__, 'pluginprefix_function_to_run' );



// Convert .docx file's to text
if (!function_exists('readDocx')){
    function readDocx($filePath) {
        // Create new ZIP archive
        $zip = new ZipArchive;
        $dataFile = 'word/document.xml';
        // Open received archive file
        if (true === $zip->open($filePath)) {
            // If done, search for the data file in the archive
            if (($index = $zip->locateName($dataFile)) !== false) {
                // If found, read it to the string
                $data = $zip->getFromIndex($index);
                // Close archive file
                $zip->close();
                // Load XML from a string
                // Skip errors and warnings
                $xml = DOMDocument::loadXML($data, LIBXML_NOENT | LIBXML_XINCLUDE | LIBXML_NOERROR | LIBXML_NOWARNING);
                // Return data without XML formatting tags
    
                $contents = explode('\n',strip_tags($xml->saveXML()));
                $text = '';
                foreach($contents as $i=>$content) {
                    $text .= $contents[$i];
                }
                return $text;
            }
            $zip->close();
        }
        // In case of failure return empty string
        return "";
    }
}
// Retrieve text from .docx file from server`
if (!function_exists('dynamic_text_area')){
    function dynamic_text_area( $atts ){
        // Retrieve the file location from site directory with same name as the page slug.
        $currentDirectory = getcwd();
        $currentPage = $_SERVER['REQUEST_URI'];
        $file = $currentDirectory . "/teksten" . $currentPage . ".docx";
        // Convert the document to text, and to html after that. 
        $converted_document = readDocx($file);
        $html_document = html_entity_decode ($converted_document);
        // Build the url
        $url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
        // Add delimeters for preg_match
        $dirString = strval($currentPage) . "/";
            // Check if the current pagename slug exists in the url
            if (preg_match($dirString, $url)) {
                // Retrieve the content and explode the array
                $text = explode('[placeholder dynamic text]', $html_document);
            } else {
                echo "Pagename and url dont match". "<br>";
                $text = the_post();
            }
        // Check for shortcode attribute used, retrieve according text
        extract( shortcode_atts( array(
            'type' => 'myvalue'

        ), $atts ) );

        switch( $type ){
            case 'textone': 
                $output = $text[1];
                break;
            case 'texttwo': 
                $output = $text[2];
                break;
            case 'textthree': 
                $output = $text[3];
                break;
            case 'textfour': 
                $output = $text[4];
                break;
            case 'textfive': 
                $output = $text[5];
                break;
            case 'textsix': 
                $output = $text[6];
                break;
            case 'textseven': 
                $output = $text[7];
                break;
            case 'texteight': 
                $output = $text[8];
                break;
            case 'textnine': 
                $output = $text[9];
                break;
            default:
                $output = $text[0];
                break;
        }
        return $output;
}
add_shortcode( 'textload', 'dynamic_text_area' );
}
?>